# 蚂蚁灵波挑战赛 RTX 5090 在线部署指南

更新：2026 年 10 月 15 日。适用于 Ubuntu 24.04 x86_64 单卡机器，从互联网下载 LingBot VLA v2 源码、RoboTwin 仿真资产、通用预训练权重和样例数据，构建环境并运行一次完整仿真闭环。

本文配套 `5090在线部署配套.zip`，其中只有 Dockerfile 和部署辅助脚本。模型、仿真源码、资产及训练数据均由目标机器从官方公开来源下载，无需 Pro 5000 的镜像、U 盘备份或已有 LoRA 权重。

Pro 5000 已验证的参考组合是 PyTorch 2.8.0 + CUDA 12.8、模型 Python 3.12、仿真 Python 3.10，并关闭不兼容的 OIDN 降噪。本次在线构建使用公开 NVIDIA 基础镜像重建这套核心组合，未在一台全新 5090 上完成端到端安装实测；应按第八至第十步逐项验收。

**一、最终要得到什么**

目标流程是：系统驱动 → Docker GPU 支持 → 下载锁定源码 → 构建模型与仿真容器 → 下载权重和资产 → 准备路径及推理配置 → GPU/场景验收 → 通用预训练模型单回合闭环。

模型容器负责从三路图像和 14 维机器人状态预测动作；仿真容器负责生成场景、渲染图像、执行动作和写出视频。两者通过内部 Docker 网络的 9330 端口通信。容器内项目路径始终是 `/competition`，宿主机项目可放在自己的磁盘目录中。

本教程使用 `robbyant/lingbot-vla-v2-6b` 通用预训练权重。官方另有 RoboTwin 后训练权重，二者不能混称；本教程不自动切换成后训练模型，也不加载我们自己训练的 best4500 LoRA。基础模型在某一回合失败，不等于部署失败：部署验收看是否完成推理、动作执行和结果保存，任务成功率另行评估。

**二、版本与下载地址**

| 内容 | 来源与用途 |
|---|---|
| LingBot VLA v2 | [官方 GitHub](https://github.com/Robbyant/lingbot-vla-v2)，模型与策略服务代码 |
| RoboTwin | [官方 GitHub](https://github.com/RoboTwin-Platform/RoboTwin)，仿真任务代码 |
| cuRobo | [NVIDIA GitHub](https://github.com/NVlabs/curobo)，GPU 运动规划 |
| 通用预训练权重 | [robbyant/lingbot-vla-v2-6b](https://huggingface.co/robbyant/lingbot-vla-v2-6b) |
| Qwen 视觉语言骨干 | [Qwen3-VL-4B-Instruct](https://huggingface.co/Qwen/Qwen3-VL-4B-Instruct)，模型配置、processor 与骨干资源 |
| 仿真资产和轨迹数据 | [TianxingChen/RoboTwin2.0](https://huggingface.co/datasets/TianxingChen/RoboTwin2.0/tree/main) |
| 公共 CUDA 镜像 | [NVIDIA CUDA 镜像仓库](https://hub.docker.com/r/nvidia/cuda)，本机在线构建的基础 |
| FlashAttention wheel | [官方 v2.8.3 发布页](https://github.com/Dao-AILab/flash-attention/releases/tag/v2.8.3) |

配套脚本锁定以下源码与数据，避免直接使用未来变化的 main 分支：

```text
LingBot  be969b8fd117fb70550c5d4bf4bc328211b5b1b6
RoboTwin 13c3c47ff4312dd62484bcd51be034af55c062d1
cuRobo   d64c4b005459db10c5dd867d8b30a87d5bda9bdb
VLA 模型 11c703bf6a5c1f45b3b69168482da11fdbba53d7
数据集   3dc3b798668feb99ac61cc9086d84cbcc3d79186
```

Qwen 首次下载时解析当前 revision，立即写入 `reports/online-resource-lock.json`，之后重复下载使用该 revision。这提供本次安装的可复现记录，但不能证明与旧 Pro 5000 的 Qwen 快照完全相同。

| 环境 | Python | PyTorch / CUDA | 关键依赖 |
|---|---|---|---|
| 模型容器 | 3.12，Ubuntu 24.04 基础镜像 | 2.8.0 / 12.8 | torchvision 0.23.0；FlashAttention 2.8.3；LeRobot 0.4.2 |
| 仿真容器 | 3.10，Ubuntu 22.04 基础镜像 | 2.8.0 / 12.8 | SAPIEN 3.0.0b1；mplib 0.2.1；NumPy 1.26.4；cuRobo 0.7.8 版本源码 |

宿主 Ubuntu 24.04 可以运行 Ubuntu 22.04 容器。不要将两个 Python 环境混在一起。完整依赖见配套 Dockerfile 和 `docker/sim-requirements.txt`；部分传递依赖仍由安装器解析，构建后应保存 pip freeze。

**三、准备宿主机和 NVIDIA 驱动**

建议内存至少 64 GB，项目与 Docker 所在磁盘合计至少预留 400 GB 可用空间。模型加载有 CPU 内存峰值；下载 ZIP、解压数据、构建镜像和后续检查点也会同时占用磁盘。这是容量建议，实际占用取决于下载范围。

先安装支持实际 5090 型号的 NVIDIA 驱动。Ubuntu 可通过“软件和更新 → 附加驱动”选取适合当前显卡的推荐驱动，安装后重启。Pro 5000 参考驱动是 595.99.02，这不是本教程声明的最低驱动版本。

```bash
nvidia-smi
nvidia-smi --query-gpu=name,driver_version,memory.total,memory.free --format=csv
free -h
df -h
sudo apt-get update
sudo apt-get install -y git curl ca-certificates gnupg python3 unzip
```

`nvidia-smi` 应能正确显示目标 GPU。CUDA 程序将在容器中运行，宿主机不需要再建立项目 Conda 环境；编译所需 nvcc 已包含在后面使用的 CUDA devel 镜像中。

**四、安装 Docker 和 NVIDIA Container Toolkit**

以下命令用于尚未安装 Docker 的 Ubuntu 24.04 新机器。若已有可用 Docker，先执行 `docker info`，跳过重复安装；存在不同来源的 Docker 包时，按 [Docker 官方说明](https://docs.docker.com/engine/install/ubuntu/)处理冲突。

```bash
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
sudo tee /etc/apt/sources.list.d/docker.sources >/dev/null <<'DOCKER_REPO'
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: noble
Components: stable
Architectures: amd64
Signed-By: /etc/apt/keyrings/docker.asc
DOCKER_REPO
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io \
  docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker "$USER"
```

退出登录后重新登录，使用户组生效，再执行 `docker info`。Docker 用户组提供管理容器的高权限，应只授予该机器的可信使用者。

按照 [NVIDIA Container Toolkit 官方说明](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html)配置源并启用 GPU：

```bash
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | \
  sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -fsSL https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
  sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker

docker run --rm --gpus all \
  nvidia/cuda:12.8.1-devel-ubuntu24.04 nvidia-smi
```

最后一条会从网上拉取 NVIDIA 基础镜像，并验证容器能够访问 GPU。Docker 重启应在这台机器尚未运行训练任务时完成。

**五、准备部署脚本并从网上获取源码**

把本指南附带的 `5090在线部署配套.zip` 下载到目标电脑。这个小文件仅包含安装配方和辅助脚本，不含任何镜像、预训练权重或数据。将下方 ZIP 路径改为实际下载路径：

```bash
mkdir -p "$HOME/lingbo-online"
cd "$HOME/lingbo-online"
unzip "$HOME/Downloads/5090在线部署配套.zip"
cd 5090在线部署配套
export PROJECT="$PWD"
bash scripts/get_sources.sh
```

其实际网络操作是从第二节三个 GitHub 仓库克隆源码并 checkout 指定 commit，同时给 RoboTwin 的 OIDN 选项加上环境变量开关。不会访问 Pro 5000，也不会读取其凭据。

后面的所有命令从 `$PROJECT` 运行；新终端请重新 `cd` 到该目录。下载后应出现：

```text
sources/lingbot-vla-v2/
sources/RoboTwin/
sources/curobo/
docker/
scripts/
models/
data/
configs/
reports/
outputs/
```

**六、在线构建两个容器环境**

```bash
cd "$PROJECT"
set -o pipefail
docker build --progress=plain -f docker/model.Dockerfile \
  -t lingbo-online-model:cu128 . 2>&1 | tee reports/build-model.log
docker build --progress=plain -f docker/sim.Dockerfile \
  -t lingbo-online-sim:cu128 . 2>&1 | tee reports/build-sim.log
```

这两个镜像标签是本机新生成的名字，不能直接从公共仓库 pull。真正在线拉取的基础镜像分别是 `nvidia/cuda:12.8.1-devel-ubuntu24.04` 和 `nvidia/cuda:12.8.1-devel-ubuntu22.04`。

模型构建安装 cu128 的 PyTorch 2.8.0、官方项目 requirements、匹配 Python 3.12/PyTorch 2.8/C++ ABI TRUE 的 FlashAttention wheel，以及 LeRobot 数据转换依赖。它还加入关闭辅助 teacher loss 的开关，供可选的短 LoRA 训练验收使用；首次推理不需要额外下载全部 teacher 模型。

仿真构建安装 SAPIEN、mplib、Open3D 等依赖，并在 CUDA 12.8 devel 镜像内按 `TORCH_CUDA_ARCH_LIST=12.0` 编译 cuRobo。构建并发设为 4；内存较小导致编译进程被 killed 时，可把 Dockerfile 中 `MAX_JOBS` 调成 1 后重新构建。

不要直接使用上游旧 Dockerfile 或原封不动执行 RoboTwin `_install.sh`：我们锁定的这些文件包含较旧 PyTorch 版本。本教程的 Dockerfile 已把 Blackwell 相关版本配对显式写出。

保存构建结果和实际依赖：

```bash
docker image inspect lingbo-online-model:cu128 lingbo-online-sim:cu128 \
  > reports/online-images.json
docker run --rm --entrypoint pip lingbo-online-model:cu128 freeze \
  > reports/online-model-freeze.txt
docker run --rm --entrypoint pip lingbo-online-sim:cu128 freeze \
  > reports/online-sim-freeze.txt
```

**七、下载预训练权重和仿真资源**

```bash
bash scripts/container.sh download
```

该命令会联网下载：

- `robbyant/lingbot-vla-v2-6b` 的完整快照，保存到 `models/lingbot-vla-v2-6b`。
- `Qwen/Qwen3-VL-4B-Instruct` 的完整快照，保存到 `models/Qwen3-VL-4B-Instruct`。
- `objects.zip`、`embodiments.zip`、`background_texture.zip`，保存到 `data/assets`。
- `dataset/click_bell/aloha-agilex_clean_50.zip`，保存到 `data/archives`。

下载器对文件检查大小，计算 SHA256，并与 Hugging Face 提供的 LFS SHA256 对照；结果写入 `reports/online-download-verified.json`。最终出现 `DOWNLOAD_AND_HASH_CHECK_PASS` 才进入下一步。网络中断后可以重复执行，完整文件利用本地缓存，但校验仍会读取文件。

这里额外下载 click_bell 的 clean 轨迹，是为了生成当前通用预训练模型测试用的状态/动作归一化统计，以及可选短训练验收。它不是运行所有仿真场景都必需的“仿真资产”。首次无需下载整个 RoboTwin 数据仓库。

需要全部 50 个 clean 任务训练 ZIP 时，再执行：

```bash
bash scripts/container.sh download --all-clean
```

这个选项只扩充下载范围，不会自动转换全部数据或启动训练。

网络需要代理时，要分别配置宿主 Git、Docker daemon 的镜像拉取代理、Docker build 的构建代理，以及下载容器的代理。现有下载 wrapper 不自动转发代理变量；可在 `scripts/container.sh` 的 download 分支加入 `-e HTTPS_PROXY -e HTTP_PROXY -e NO_PROXY`，使用容器能够访问的代理地址。宿主 `127.0.0.1` 通常不是容器可访问的代理地址。联网下载阶段完成后，运行验收保持离线模式。

**八、解压资产并生成推理配置**

```bash
python3 scripts/prepare_sim_assets.py
bash scripts/container.sh sim script/update_embodiment_config_path.py
bash scripts/container.sh model /competition/scripts/convert_click_bell.py
bash scripts/container.sh model /competition/scripts/prepare_click_bell_config.py
```

四条命令依次完成：解压三个资产包和 click_bell 数据、建立相对目录链接；按容器路径重新生成 cuRobo 机器人配置；转换 clean 轨迹到 LeRobot 并计算归一化统计；生成推理需要的 YAML 配置和 hf_ckpt 链接。

资产解压脚本要求磁盘在解压量之外另保留 80 GiB 空闲空间。LeRobot 转换输出目录已存在时会拒绝覆盖；转换完成后不要重复运行，失败后先保留旧输出，再清理或换目录重试。

预期关键产物：

```text
data/assets/{objects,embodiments,background_texture}/
data/raw/click_bell/aloha-agilex_clean_50/
data/lerobot/click_bell_clean_50/
configs/click_bell_norm.json
outputs/pretrained_click_bell_smoke/lingbotvla_cli.yaml
outputs/pretrained_click_bell_smoke/checkpoints/global_step_0/hf_ckpt
```

`hf_ckpt` 是指向刚下载的原始权重目录的链接，step_0 仅表示尚未训练。这个目录布局是当前服务加载器要求的：它会向上查找 `lingbotvla_cli.yaml`，因此不能只把一个任意模型文件夹直接传给服务。

这里的归一化来自 click_bell clean 50 条轨迹，用于单任务链路验收，不能当作完整 50 任务正式评测的归一化方案。处理完成应在 `reports/click-bell-preprocessing-check.json` 看到 `status: pass`。

**九、5090 GPU 与仿真渲染验收**

```bash
bash scripts/container.sh model /competition/scripts/check_gpu.py
bash scripts/container.sh sim /competition/scripts/check_gpu.py
```

模型容器应输出 `CUDA_PASS` 和 `FLASH_ATTENTION_PASS`，仿真容器应输出 `CUDA_PASS`。检查显示的实际 GPU 是目标 5090、计算能力为 `(12, 0)`、CUDA 为 12.8。仿真容器没有 FlashAttention 属于预期。GPU 架构可对照 [NVIDIA 官方表](https://developer.nvidia.com/cuda/gpus)。

检查宿主图形驱动配置：

```bash
test -f /usr/share/vulkan/icd.d/nvidia_icd.json
test -f /usr/share/glvnd/egl_vendor.d/10_nvidia.json
bash scripts/container.sh sim -c \
  'import subprocess; subprocess.run(["vulkaninfo","--summary"],check=True)'
bash scripts/container.sh sim /competition/scripts/check_click_bell_scene.py
```

驱动 JSON 不在上述路径时，用 `find /usr/share /etc -name '*nvidia*.json' 2>/dev/null` 找实际文件，再同时修改 `container.sh` 和 `run_pretrained.sh` 中的宿主挂载路径。不要用空文件替代真实驱动 JSON。

场景检查应生成 `reports/click-bell-scene-check.json` 和三张 `outputs/click_bell_scene_*.png`，其中状态为 14 维、三路图像非空。原 Pro 5000 渲染为每路 240 × 320 × 3，模型侧进一步缩放到 256 × 256。

仿真使用 `compute,utility,graphics` 驱动能力，挂载 Vulkan/EGL 配置，并设置 `LINGBO_RAY_DENOISER=none`。这是针对 Pro 5000 上出现的 OIDN CUDA 后端不兼容；光追本身仍保持原 32 spp。缺少 PyTorch3D 的提示在当前 RGB-only 配置下可以出现；若以后启用点云 FPS，应另外完成 PyTorch3D 适配。

**十、启动原始预训练权重并执行一次闭环**

确认没有占用大量显存的其他作业，再执行：

```bash
bash scripts/run_pretrained.sh
```

脚本会检查至少 19000 MiB 空闲显存，启动内部网络和模型服务，等待 healthz，随后执行 clean click_bell 单回合。该阈值只是启动保护，不保证所有显卡、分辨率和任务都不会 OOM。本文默认单卡；多卡机器应同步调整 `--gpus all` 和 GPU 显存检查目标。

服务使用 BF16、动作 chunk 50、256 × 256 输入、关闭 torch.compile，并使用原始权重，返回动作形状 `(50, 14)`。端口 9330 仅在内部容器网络使用，无需映射到宿主公网。运行结束后脚本停止本次服务，保留容器用于读取日志。

另开终端查看：

```bash
docker logs --tail 100 lingbo-online-policy-closedloop
docker logs --tail 100 lingbo-online-sim-closedloop
```

结果位于：

```text
outputs/evaluation/online_pretrained_smoke_clean/click_bell/
```

检查模型成功处理观测，仿真执行了动作，最终写出结果及 `episode0_success.mp4` 或 `episode0_failure.mp4`。应区分“完整跑完但任务失败”和“依赖报错导致程序退出”。Pro 5000 上先前记录的单回合成功使用训练后的 LoRA，不能转述为本教程的通用预训练权重已经成功完成任务。

如果等待服务约 10 分钟仍未 ready，先读模型日志，区分加载、编译、下载缺件和内存不足，不要反复启动更多服务。

再次运行前，确认旧容器已停止并保留需要的日志，再删除指定容器：

```bash
docker inspect --format '{{.Name}} {{.State.Status}}' \
  lingbo-online-policy-closedloop lingbo-online-sim-closedloop
docker rm lingbo-online-policy-closedloop lingbo-online-sim-closedloop
```

重复运行会使用同一输出目录，需要比较两次结果时先归档旧结果。

**十一、可选的训练更新检查**

预训练闭环完成后，若还需要验证环境能否训练，可执行已有配套脚本的两次 LoRA 更新及独立回放：

```bash
bash scripts/container.sh model /competition/scripts/check_lora_training.py train
bash scripts/container.sh model /competition/scripts/check_lora_training.py verify
```

训练验收使用同一基础模型、已转换的 click_bell clean 数据和生成的归一化统计，会创建新的 `outputs/click_bell_lora_acceptance`。已存在训练验收权重时会拒绝覆盖，应先归档。该测试只验证反向传播、参数更新和检查点回放；不会改变第十步服务加载原始预训练权重的行为。

当前模型镜像针对推理及关闭辅助 teacher loss 的短训练准备。完整上游训练、所有 teacher loss、多卡训练和正式 50 任务数据管线，需要继续按官方训练配置准备相关权重及数据，不能用本次两步训练验收替代。

**十二、常见问题与验收记录**

| 问题 | 检查与处理 |
|---|---|
| 旧文档里的 lingbo-competition 镜像 pull 不到 | 那些是本地历史镜像。本流程应先构建 lingbo-online 两个镜像 |
| sm_120 / no kernel image | 检查是否实际用了 torch 2.8.0+cu128；cuRobo 是否在 CUDA 12.8 下按 12.0 编译 |
| flash_attn undefined symbol | wheel 必须同时匹配 Python 3.12、torch 2.8 和 C++ ABI；不要随意混装另一个 wheel |
| pip 构建依赖冲突 | 保存完整 build 日志，检查源码 revision；不要无约束升级 torch、numpy 或 transformers |
| SAPIEN 找不到 GPU/Vulkan | 检查宿主图形驱动、graphics capability 及两个 JSON 文件挂载 |
| OIDN 报错 | 源码必须读取环境变量，容器也必须传入 none，二者缺一不可 |
| cuRobo 找不到 URDF 或 collision_spheres | 从 RoboTwin 容器工作目录重新运行 update_embodiment_config_path.py |
| hf_ckpt 附近缺少 YAML | 先完成第八步，使用生成的 step_0/hf_ckpt 路径 |
| 文件缺失但已设置离线模式 | 回到下载阶段补齐文件，检查 download verified 报告 |
| 模型响应正常但动作效果差 | 检查输入、归一化及任务适配；通用预训练模型不等同于任务后训练策略 |
| 断网或受限网络 | 分别检查 GitHub、Docker Hub、PyTorch wheel 站点和 Hugging Face；构建成功不意味着权重已下载 |

最后保存 `online-resource-lock.json`、下载校验表、镜像 ID、pip freeze、GPU 验收输出、场景报告，以及本机闭环日志/视频。它们共同描述这台 5090 的实际环境。

本流程沿用 Pro 5000 的核心依赖与兼容性修复，但新镜像不应标注为旧镜像的相同 ID，也不能将旧验收报告作为本机测试结果。官方发布评测使用 FP32；这里的 BF16、单回合、输入缩放和关闭降噪用于本地部署验收，正式比赛评测需重新对齐主办方要求。详情见 [LingBot RoboTwin 评测说明](https://github.com/Robbyant/lingbot-vla-v2/blob/be969b8fd117fb70550c5d4bf4bc328211b5b1b6/experiment/robotwin/README.md)和 [RoboTwin 安装说明](https://robotwin-platform.github.io/doc/usage/robotwin-install.html)。
