FROM nvidia/cuda:12.8.1-devel-ubuntu24.04
ENV DEBIAN_FRONTEND=noninteractive
RUN apt-get update && apt-get install -y --no-install-recommends python3 python3-venv python3-dev git build-essential cmake ninja-build ffmpeg libgl1 libglib2.0-0 ca-certificates curl && rm -rf /var/lib/apt/lists/*
RUN python3 -m venv /opt/venv
ENV PATH=/opt/venv/bin:$PATH MAX_JOBS=4 TORCH_CUDA_ARCH_LIST=12.0
RUN pip install --upgrade pip setuptools wheel packaging ninja
RUN pip install torch==2.8.0 torchvision==0.23.0 torchaudio==2.8.0 --index-url https://download.pytorch.org/whl/cu128
COPY sources/lingbot-vla-v2 /opt/lingbot-vla-v2
WORKDIR /opt/lingbot-vla-v2
RUN pip install -r requirements.txt
RUN pip install accelerate==1.7.0 numpydantic==1.9.0 --no-deps
RUN pip install --no-deps https://github.com/huggingface/lerobot/archive/refs/tags/v0.4.2.tar.gz
RUN pip install --no-deps https://github.com/Dao-AILab/flash-attention/releases/download/v2.8.3/flash_attn-2.8.3+cu12torch2.8cxx11abiTRUE-cp312-cp312-linux_x86_64.whl
RUN pip install --no-build-isolation --no-deps -e .
COPY scripts/patch_training.py /tmp/patch_training.py
RUN python /tmp/patch_training.py
RUN python -c "import torch,flash_attn; from deploy.lingbot_vla_v2_policy import LingbotVLAv2Server; from lerobot.datasets.lerobot_dataset import LeRobotDataset; assert torch.version.cuda=='12.8'; print(torch.__version__,flash_attn.__version__)"
ENV PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 QWEN3VL_PATH=/competition/models/Qwen3-VL-4B-Instruct
ENTRYPOINT []
CMD ["bash"]
