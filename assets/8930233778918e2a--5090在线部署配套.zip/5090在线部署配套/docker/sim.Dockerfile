FROM nvidia/cuda:12.8.1-devel-ubuntu22.04
ENV DEBIAN_FRONTEND=noninteractive
RUN apt-get update && apt-get install -y --no-install-recommends python3 python3-venv python3-dev git build-essential cmake ninja-build ffmpeg libgl1 libglib2.0-0 libegl1 libglvnd0 libvulkan1 vulkan-tools libx11-6 libxext6 libxrender1 libsm6 ca-certificates && rm -rf /var/lib/apt/lists/*
RUN python3 -m venv /opt/venv
ENV PATH=/opt/venv/bin:$PATH MAX_JOBS=4 TORCH_CUDA_ARCH_LIST=12.0 SETUPTOOLS_SCM_PRETEND_VERSION=0.7.8
RUN pip install --upgrade pip wheel && pip install setuptools==69.5.1 packaging==25.0 ninja==1.11.1.4
RUN pip install torch==2.8.0 torchvision==0.23.0 --index-url https://download.pytorch.org/whl/cu128
COPY docker/sim-requirements.txt /tmp/requirements.txt
RUN pip install -r /tmp/requirements.txt
COPY sources/curobo /opt/curobo
WORKDIR /opt/curobo
RUN pip install --no-build-isolation --no-deps -e .
COPY scripts/patch_sim_packages.py /tmp/patch_sim_packages.py
RUN python /tmp/patch_sim_packages.py
RUN python -c "import torch,sapien,mplib,open3d; import curobo; assert torch.version.cuda=='12.8'; print(torch.__version__)"
ENV NVIDIA_DRIVER_CAPABILITIES=compute,utility,graphics PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1
ENTRYPOINT []
CMD ["bash"]
