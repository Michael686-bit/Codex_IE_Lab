"""Load a complete RoboTwin scene and capture observations; execute no policy actions."""
from pathlib import Path
import importlib
import json
import time
import sys
import yaml
import numpy as np
from PIL import Image

ROOT=Path('/competition')
REPO=ROOT/'sources/RoboTwin'
sys.path.insert(0,str(REPO))
args=yaml.safe_load((REPO/'task_config/demo_clean.yml').read_text())
args.update(task_name='click_bell',task_config='demo_clean',ckpt_setting='scene_acceptance',
            policy_name='lingbot_vla_v2',collect_data=False,eval_video_log=False)
embodiments=yaml.safe_load((REPO/'task_config/_embodiment_config.yml').read_text())
robot_file=embodiments['aloha-agilex']['file_path']
robot=yaml.safe_load((REPO/robot_file/'config.yml').read_text())
args.update(left_robot_file=robot_file,right_robot_file=robot_file,dual_arm_embodied=True,
            left_embodiment_config=robot,right_embodiment_config=robot)
cameras=yaml.safe_load((REPO/'task_config/_camera_config.yml').read_text())
camera=cameras[args['camera']['head_camera_type']]
args.update(head_camera_h=camera['h'],head_camera_w=camera['w'])
env=getattr(importlib.import_module('envs.click_bell'),'click_bell')()
started=time.perf_counter()
try:
    env.setup_demo(now_ep_num=0,seed=100000,is_test=True,**args)
    observation=env.get_obs()
    state=np.asarray(observation['joint_action']['vector'])
    assert state.shape==(14,) and np.isfinite(state).all(),state.shape
    shapes={}
    for name in ['head_camera','left_camera','right_camera']:
        image=np.asarray(observation['observation'][name]['rgb'])
        assert image.ndim==3 and image.shape[-1]==3 and np.isfinite(image).all()
        assert image.std()>0.01
        shapes[name]=list(image.shape)
        Image.fromarray(image.astype(np.uint8)).save(ROOT/f'outputs/click_bell_scene_{name}.png')
    report={'status':'pass','scene':'click_bell demo_clean seed100000','state_shape':list(state.shape),
            'camera_shapes':shapes,'elapsed_seconds':time.perf_counter()-started,
            'policy_actions_executed':False,'success_rate_measured':False}
    (ROOT/'reports/click-bell-scene-check.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)
finally:
    env.close_env(clear_cache=True)
