import torch
print(torch.__version__,torch.version.cuda)
assert torch.version.cuda=='12.8' and torch.cuda.is_available()
print(torch.cuda.get_device_name(),torch.cuda.get_device_capability())
x=torch.randn(128,128,device='cuda',dtype=torch.bfloat16,requires_grad=True)
y=(x@x).float().square().mean(); y.backward(); torch.cuda.synchronize()
assert torch.isfinite(y) and torch.isfinite(x.grad).all()
print('CUDA_PASS')
try:import flash_attn
except ImportError:print('FlashAttention absent in sim environment: expected')
else:
    from flash_attn import flash_attn_func
    q,k,v=[torch.randn(1,128,8,64,device='cuda',dtype=torch.bfloat16,requires_grad=True) for _ in range(3)]
    o=flash_attn_func(q,k,v); o.float().square().mean().backward(); torch.cuda.synchronize()
    assert torch.isfinite(o).all() and all(torch.isfinite(t.grad).all() for t in (q,k,v))
    print('FLASH_ATTENTION_PASS',flash_attn.__version__)
