"""Two-update action-expert LoRA acceptance with independent checkpoint replay."""
import argparse
import importlib
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import time
import numpy as np
import cv2
import torch
import yaml
from peft import LoraConfig, inject_adapter_in_model
from safetensors.torch import load_file, save_file
from lerobot.datasets.lerobot_dataset import LeRobotDataset

ROOT=Path('/competition')
OUT=ROOT/'outputs/click_bell_lora_acceptance'
BASE=ROOT/'outputs/pretrained_click_bell_smoke/checkpoints/global_step_0/hf_ckpt'
parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['train','verify']);args=parser.parse_args()
OUT.mkdir(parents=True,exist_ok=True)
if args.mode=='train' and (OUT/'trainable.safetensors').exists():raise RuntimeError('Refusing to overwrite acceptance checkpoint')
torch.manual_seed(42);torch.cuda.manual_seed_all(42)
torch.cuda.set_per_process_memory_fraction(0.76)
torch.set_float32_matmul_precision('highest')
torch.distributed.init_process_group('gloo',init_method='file:///tmp/click-bell-single-rank',rank=0,world_size=1)
from lingbotvla.distributed.parallel_state import init_parallel_state
init_parallel_state(dp_mode='ddp')
from deploy.lingbot_vla_v2_policy import LingbotVLAv2Server
from lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla import apply_lingbot_qwen3_vl_patch
from lingbotvla.data.vla_data.utils import FeatureTransform
apply_lingbot_qwen3_vl_patch()
import lingbotvla.models.vla.lingbot_vla.qwen2_action_expert as action_module
action_module.robby_moe_forward=None
server=LingbotVLAv2Server.__new__(LingbotVLAv2Server)
server.use_compile=False;server.robot_norm_path=None
model=server.load_vla(str(BASE))
config=model.config
config.loss_type='fm';config.compute_auxiliary_losses=False
config.sequence_wise_loss_coeff=0.;config.router_z_loss_coeff=0.;config.bias_update_speed=0.
config.use_cache=False;config.freeze_vision_encoder=True;config.train_expert_only=True
model.model.qwenvl_with_expert.config.freeze_vision_encoder=True
model.model.qwenvl_with_expert.config.train_expert_only=True
attention=model.model.qwenvl_with_expert
flex_module=importlib.import_module('lingbotvla.models.vla.lingbot_vla.flex_attention')
flex_module.flex_attention=torch.compile(flex_module.flex_attention,fullgraph=True,dynamic=False)
attention.config.attention_implementation='flex_cached'
attention.attention_interface=attention.get_attention_interface()
model.requires_grad_(False)
expert=model.model.qwenvl_with_expert.qwen_expert
targets=[n for n,m in expert.named_modules() if isinstance(m,torch.nn.Linear) and n.endswith(('.q_proj','.k_proj','.v_proj','.o_proj'))]
assert len(targets)==144
inject_adapter_in_model(LoraConfig(r=8,lora_alpha=16,lora_dropout=0.,target_modules=targets),expert)
model.to(dtype=torch.bfloat16,device='cuda')
for n,p in model.named_parameters():
    p.requires_grad_('lora_' in n or any(n.startswith('model.'+x+'.') for x in ('state_proj','action_in_proj','action_out_proj')))
    if p.requires_grad:p.data=p.data.float()
model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False})
cfg=yaml.safe_load((ROOT/'configs/click_bell_smoke.yaml').read_text())
tf=FeatureTransform(str(ROOT/'configs/robot_configs/robotwin.yaml'),SimpleNamespace(**cfg['data']),config,
                    server.processor,chunk_size=50,norm_stats_path=str(ROOT/'configs/click_bell_norm.json'),
                    use_depth_align=False,use_future_image=False,image_augment=False)
ds=LeRobotDataset('local/click_bell_clean_50',root=ROOT/'data/lerobot/click_bell_clean_50')

def batch(index,training=True):
    item=ds[index]
    for key in list(item):
        if key.startswith('observation.images.'):
            image=(item[key].permute(1,2,0).numpy()*255).round().astype(np.uint8)
            image=cv2.resize(image,(256,256),interpolation=cv2.INTER_AREA)
            item[key]=torch.from_numpy(image).permute(2,0,1).float()/255
    if training:
        item['action']=torch.stack([ds[index+i]['action'] for i in range(50)])
        item['action_is_pad']=torch.zeros(50,dtype=torch.bool)
    item=tf.apply(item,policy_eval=not training)
    keys=('images','img_masks','state','lang_tokens','lang_masks','actions','joint_mask','image_grid_thw','action_is_pad')
    return {k:v.unsqueeze(0).to('cuda',dtype=torch.bfloat16 if k in ('images','state','actions') else None)
            for k,v in item.items() if k in keys}

def frozen_digest():
    digest=hashlib.sha256()
    for name,p in model.named_parameters():
        if p.requires_grad:continue
        digest.update(name.encode());digest.update(p.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()

def predict():
    model.eval();b=batch(0,False)
    inputs={k:v for k,v in b.items() if k in ('images','img_masks','lang_tokens','lang_masks','state','image_grid_thw')}
    generator=torch.Generator(device='cuda').manual_seed(20261010)
    noise=torch.randn((1,50,55),generator=generator,device='cuda',dtype=torch.bfloat16)
    config.use_cache=True
    attention.config.attention_implementation='eager'
    attention.attention_interface=attention.get_attention_interface()
    try:
        with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):result=model.sample_actions(**inputs,noise=noise)
    finally:
        config.use_cache=False
        attention.config.attention_implementation='flex_cached'
        attention.attention_interface=attention.get_attention_interface()
    assert torch.isfinite(result).all()
    return result.float().cpu().numpy()

named=dict(model.named_parameters());params=[p for p in model.parameters() if p.requires_grad]
optimizer=torch.optim.AdamW(params,lr=1e-4)
frozen=frozen_digest()
report={'mode':args.mode,'trainable_parameters':sum(p.numel() for p in params),'lora_modules':len(targets),
        'base_model':'robbyant/lingbot-vla-v2-6b','training_data':'click_bell clean',
        'auxiliary_teacher_losses':False,'native_queries_preserved':True,'formal_training':False,
        'training_attention':'flex_cached','replay_attention':'eager','input_resolution':[256,256],
        'original_dataset_resolution':[480,640],'pytorch_allocator_fraction':0.76}
if args.mode=='train':
    initial={n:p.detach().cpu().clone() for n,p in named.items() if p.requires_grad}
    metrics=[]
    for step in [1,2]:
        model.train();b=batch(step-1);optimizer.zero_grad(set_to_none=True);tick=time.perf_counter()
        with torch.autocast('cuda',dtype=torch.bfloat16):loss=model(**b)[0]
        assert torch.isfinite(loss);loss.backward()
        assert any(p.grad is not None and p.grad.abs().sum()>0 for n,p in named.items() if 'lora_B' in n)
        assert all(torch.isfinite(p.grad).all() for p in params if p.grad is not None)
        grad=float(torch.nn.utils.clip_grad_norm_(params,1.));assert np.isfinite(grad) and grad>0
        optimizer.step();torch.cuda.synchronize()
        free,_=torch.cuda.mem_get_info();assert free>=2*1024**3
        metrics.append({'step':step,'loss':float(loss.detach()),'gradient_norm':grad,'seconds':time.perf_counter()-tick})
        print(json.dumps(metrics[-1]),flush=True);del loss,b
    optimizer.zero_grad(set_to_none=True)
    torch.cuda.empty_cache()
    assert frozen_digest()==frozen
    assert any(not torch.equal(initial[n],p.detach().cpu()) for n,p in named.items() if 'lora_' in n)
    save_file({n:p.detach().cpu().contiguous() for n,p in named.items() if p.requires_grad},str(OUT/'trainable.safetensors'))
    torch.save({'step':2,'optimizer':optimizer.state_dict(),'torch_rng':torch.get_rng_state(),
                'cuda_rng':torch.cuda.get_rng_state_all(),'frozen_digest':frozen},OUT/'training_state.pt')
    np.save(OUT/'reference_prediction.npy',predict())
    report.update(status='pass',updates=2,metrics=metrics,frozen_unchanged=True)
else:
    saved=load_file(str(OUT/'trainable.safetensors'));assert set(saved)=={n for n,p in named.items() if p.requires_grad}
    with torch.no_grad():
        for name,value in saved.items():named[name].copy_(value.to(named[name].device))
    state=torch.load(OUT/'training_state.pt',map_location='cpu',weights_only=False)
    assert state['frozen_digest']==frozen
    optimizer.load_state_dict(state['optimizer'])
    torch.set_rng_state(state['torch_rng']);torch.cuda.set_rng_state_all(state['cuda_rng'])
    reference=np.load(OUT/'reference_prediction.npy');actual=predict()
    error=float(np.max(np.abs(reference-actual)))
    assert np.allclose(reference,actual,atol=1e-5,rtol=1e-4),error
    assert frozen_digest()==frozen
    report.update(status='pass',restored_step=state['step'],optimizer_restored=bool(optimizer.state),reload_max_error=error)
report['peak_allocated_mib']=torch.cuda.max_memory_allocated()/1024**2
(ROOT/f'reports/click-bell-lora-{args.mode}.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
torch.distributed.destroy_process_group()
