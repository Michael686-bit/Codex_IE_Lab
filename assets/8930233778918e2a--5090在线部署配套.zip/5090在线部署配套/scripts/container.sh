#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
MODE="${1:?model|download|sim}"; shift
BASE=(--rm --init --user "$(id -u):$(id -g)" -e HOME=/tmp -e USER=runner -e LOGNAME=runner -e PYTHONUNBUFFERED=1 -v "$PWD:/competition")
case "$MODE" in
  download)
    docker run "${BASE[@]}" -e HF_HOME=/competition/cache/huggingface -e HF_HUB_DOWNLOAD_TIMEOUT=120 \
      --entrypoint python lingbo-online-model:cu128 /competition/scripts/download.py "$@" ;;
  model)
    docker run "${BASE[@]}" --gpus all --network none -w /opt/lingbot-vla-v2 \
      -e HF_HUB_OFFLINE=1 -e HF_DATASETS_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 \
      -e TRITON_CACHE_DIR=/competition/cache/triton -e QWEN3VL_PATH=/competition/models/Qwen3-VL-4B-Instruct \
      --entrypoint python lingbo-online-model:cu128 "$@" ;;
  sim)
    for f in /usr/share/vulkan/icd.d/nvidia_icd.json /usr/share/glvnd/egl_vendor.d/10_nvidia.json; do
      [[ -f "$f" ]] || { echo "Missing driver file: $f" >&2; exit 1; }
    done
    docker run "${BASE[@]}" --gpus all --network none -w /competition/sources/RoboTwin \
      -e NVIDIA_DRIVER_CAPABILITIES=compute,utility,graphics -e XDG_RUNTIME_DIR=/tmp \
      -e VK_ICD_FILENAMES=/etc/vulkan/icd.d/nvidia_icd.json \
      -e __EGL_VENDOR_LIBRARY_FILENAMES=/usr/share/glvnd/egl_vendor.d/10_nvidia.json \
      -e LINGBO_RAY_DENOISER=none -e TORCH_EXTENSIONS_DIR=/competition/cache/torch_extensions_5090 -e MAX_JOBS=4 \
      -v /usr/share/vulkan/icd.d/nvidia_icd.json:/etc/vulkan/icd.d/nvidia_icd.json:ro \
      -v /usr/share/glvnd/egl_vendor.d/10_nvidia.json:/usr/share/glvnd/egl_vendor.d/10_nvidia.json:ro \
      --entrypoint python lingbo-online-sim:cu128 "$@" ;;
  *) echo 'Use model, download or sim' >&2; exit 2 ;;
esac
