"""Convert clean HDF5 trajectories using the official RoboTwin next-step action alignment."""
from pathlib import Path
import json
import time
import cv2
import h5py
import numpy as np
from lerobot.datasets.lerobot_dataset import LeRobotDataset

ROOT = Path('/competition')
RAW = ROOT / 'data/raw/click_bell/aloha-agilex_clean_50'
OUTPUT = ROOT / 'data/lerobot/click_bell_clean_50'
REPORT = ROOT / 'reports/click-bell-conversion.json'
if OUTPUT.exists():
    raise RuntimeError(f'Refusing to overwrite existing dataset: {OUTPUT}')
features = {
    'observation.state': {'dtype': 'float32', 'shape': (14,), 'names': [f'joint_{i}' for i in range(14)]},
    'action': {'dtype': 'float32', 'shape': (14,), 'names': [f'joint_{i}' for i in range(14)]},
}
cameras = {'cam_high': 'head_camera', 'cam_left_wrist': 'left_camera', 'cam_right_wrist': 'right_camera'}
for name in cameras:
    features['observation.images.' + name] = {'dtype': 'image', 'shape': (3, 480, 640), 'names': ['channels','height','width']}
ds = LeRobotDataset.create(repo_id='local/click_bell_clean_50', root=OUTPUT, fps=50,
                           features=features, robot_type='aloha-agilex', use_videos=False,
                           image_writer_processes=0, image_writer_threads=4)
report = {'status': 'converting', 'episodes': [], 'format': 'LeRobot v3.0',
          'image_storage': 'PNG images', 'fps': 50, 'action_alignment': 'state[t] -> joint_action[t+1]',
          'camera_decode': 'cv2.imdecode and resize, matching official RoboTwin conversion',
          'training_setting': 'clean', 'started_at': time.time()}
states, actions = [], []
random = np.random.default_rng(42)
try:
    for episode in range(50):
        prompts = json.loads((RAW / f'instructions/episode{episode}.json').read_text())['seen']
        prompt = str(random.choice(prompts))
        with h5py.File(RAW / f'data/episode{episode}.hdf5') as f:
            joint = np.column_stack([f['joint_action/left_arm'][:], f['joint_action/left_gripper'][:],
                                     f['joint_action/right_arm'][:], f['joint_action/right_gripper'][:]]).astype(np.float32)
            assert joint.shape[1] == 14 and np.isfinite(joint).all()
            assert np.allclose(joint, f['joint_action/vector'][:], atol=1e-5)
            states.append(joint[:-1]); actions.append(joint[1:])
            for t in range(len(joint) - 1):
                frame = {'observation.state': joint[t].copy(), 'action': joint[t+1].copy(), 'task': prompt}
                for name, raw_name in cameras.items():
                    image = cv2.imdecode(np.frombuffer(f[f'observation/{raw_name}/rgb'][t],np.uint8),cv2.IMREAD_COLOR)
                    if image is None: raise ValueError(f'Image decode failed: {episode} {t} {name}')
                    frame['observation.images.'+name] = cv2.resize(image,(640,480))
                ds.add_frame(frame)
        ds.save_episode()
        report['episodes'].append({'episode': episode, 'frames': len(joint)-1, 'task': prompt})
        REPORT.write_text(json.dumps(report,indent=2)+'\n')
        print('CONVERTED', episode, len(joint)-1, flush=True)
    ds.finalize()
    stats = {}
    for prefix, rows in [('observation.state',np.concatenate(states)),('action',np.concatenate(actions))]:
        for suffix, indices in [('arm.position',[0,1,2,3,4,5,7,8,9,10,11,12]),('effector.position',[6,13])]:
            values = rows[:,indices].astype(np.float64)
            stat = {'mean': values.mean(0), 'std': values.std(0), 'min': values.min(0), 'max': values.max(0)}
            for q in [1,2,98,99]:stat['q'+f'{q:02d}']=np.percentile(values,q,axis=0)
            stats[prefix+'.'+suffix] = {key:value.tolist() for key,value in stat.items()}
    (ROOT / 'configs/click_bell_norm.json').write_text(json.dumps({'norm_stats':stats},indent=2)+'\n')
    reopened = LeRobotDataset(repo_id='local/click_bell_clean_50',root=OUTPUT)
    assert reopened.num_episodes == 50
    assert reopened.num_frames == sum(e['frames'] for e in report['episodes'])
    first = reopened[0]
    assert tuple(first['observation.state'].shape)==(14,)
    assert tuple(first['observation.images.cam_high'].shape)==(3,480,640)
    report.update(status='complete',total_frames=reopened.num_frames,finished_at=time.time())
    REPORT.write_text(json.dumps(report,indent=2)+'\n')
    print('DATASET_RELOAD_PASS', reopened.num_episodes, reopened.num_frames, flush=True)
except Exception as exc:
    report.update(status='failed',error=str(exc));REPORT.write_text(json.dumps(report,indent=2)+'\n')
    raise
