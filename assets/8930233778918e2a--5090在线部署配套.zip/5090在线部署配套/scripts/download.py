"""Online-only resources; pin revisions and verify LFS SHA256 before use."""
from pathlib import Path
import argparse,json,hashlib
from huggingface_hub import HfApi,snapshot_download,hf_hub_download
root=Path('/competition'); api=HfApi()
p=argparse.ArgumentParser(); p.add_argument('--all-clean',action='store_true'); args=p.parse_args()
lockpath=root/'reports/online-resource-lock.json'
if lockpath.exists():
    lock=json.loads(lockpath.read_text())
else:
    lock={'model':'11c703bf6a5c1f45b3b69168482da11fdbba53d7',
          'dataset':'3dc3b798668feb99ac61cc9086d84cbcc3d79186',
          'qwen':api.model_info('Qwen/Qwen3-VL-4B-Instruct').sha}
    lockpath.write_text(json.dumps(lock,indent=2)+'\n')
jobs=[('robbyant/lingbot-vla-v2-6b','model',lock['model'],'models/lingbot-vla-v2-6b',None),
      ('Qwen/Qwen3-VL-4B-Instruct','model',lock['qwen'],'models/Qwen3-VL-4B-Instruct',None),
      ('TianxingChen/RoboTwin2.0','dataset',lock['dataset'],'data/assets',['objects.zip','embodiments.zip','background_texture.zip']),
      ('TianxingChen/RoboTwin2.0','dataset',lock['dataset'],'data/archives',['dataset/click_bell/aloha-agilex_clean_50.zip'])]
if args.all_clean:
    files=api.list_repo_files('TianxingChen/RoboTwin2.0',repo_type='dataset',revision=lock['dataset'])
    selected=[n for n in files if n.startswith('dataset/') and n.endswith('/aloha-agilex_clean_50.zip')]
    assert len(selected)==50, f'Expected 50 clean task archives, got {len(selected)}'
    jobs[-1]=(*jobs[-1][:4],selected)
verified=[]
for repo,kind,revision,dest,selected in jobs:
    if selected is None:
        snapshot_download(repo,repo_type=kind,revision=revision,local_dir=root/dest,max_workers=4)
        selected=api.list_repo_files(repo,repo_type=kind,revision=revision)
    else:
        for name in selected:
            hf_hub_download(repo,name,repo_type=kind,revision=revision,local_dir=root/dest)
    for item in api.get_paths_info(repo,paths=selected,repo_type=kind,revision=revision):
        if not hasattr(item,'size'):continue
        path=root/dest/item.path
        assert path.stat().st_size==item.size, str(path)
        h=hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
        digest=h.hexdigest()
        if item.lfs: assert digest==item.lfs.sha256, str(path)
        verified.append({'repo':repo,'revision':revision,'file':str(path.relative_to(root)),'bytes':item.size,'sha256':digest})
(root/'reports/online-download-verified.json').write_text(json.dumps(verified,indent=2)+'\n')
print('DOWNLOAD_AND_HASH_CHECK_PASS',len(verified))
