#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
mkdir -p sources models data/assets data/archives cache reports outputs configs
clone_pin() {
  local url="$1" dir="$2" commit="$3"
  if [[ ! -d "$dir" ]]; then git clone "$url" "$dir"; fi
  [[ -d "$dir/.git" ]] || { echo "Not a Git repository: $dir" >&2; exit 1; }
  if [[ $(git -C "$dir" rev-parse HEAD) != "$commit" ]]; then
    [[ -z $(git -C "$dir" status --porcelain) ]] || { echo "Local changes exist: $dir" >&2; exit 1; }
    git -C "$dir" fetch origin "$commit"
    git -C "$dir" checkout --detach "$commit"
  fi
  git -C "$dir" rev-parse HEAD
}
clone_pin https://github.com/Robbyant/lingbot-vla-v2.git sources/lingbot-vla-v2 be969b8fd117fb70550c5d4bf4bc328211b5b1b6
clone_pin https://github.com/RoboTwin-Platform/RoboTwin.git sources/RoboTwin 13c3c47ff4312dd62484bcd51be034af55c062d1
clone_pin https://github.com/NVlabs/curobo.git sources/curobo d64c4b005459db10c5dd867d8b30a87d5bda9bdb
python3 - <<'PYCODE'
from pathlib import Path
p=Path('sources/RoboTwin/envs/_base_task.py'); s=p.read_text()
a='sapien.render.set_ray_tracing_denoiser("oidn")'
b='sapien.render.set_ray_tracing_denoiser(os.environ.get("LINGBO_RAY_DENOISER", "oidn"))'
assert a in s or b in s
p.write_text(s.replace(a,b))
PYCODE
