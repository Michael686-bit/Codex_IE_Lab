from pathlib import Path
import sapien,mplib
p=Path(sapien.__file__).parent/'wrapper/urdf_loader.py'
s=p.read_text()
for name in ('urdf_file','srdf_file'):
    s=s.replace(f'open({name}, "r")',f'open({name}, "r", encoding="utf-8")')
p.write_text(s)
p=Path(mplib.__file__).parent/'planner.py'
s=p.read_text()
a='if np.linalg.norm(delta_twist) < 1e-4 or collide or not within_joint_limit:'
b='if np.linalg.norm(delta_twist) < 1e-4 or not within_joint_limit:'
assert a in s or b in s
p.write_text(s.replace(a,b))
