from pathlib import Path
p=Path('/opt/lingbot-vla-v2/lingbotvla/models/vla/lingbot_vla/modeling_lingbot_vla_v2.py')
s=p.read_text()
a='        align_metrics = {}\n        if self.config.align_params != {}:\n'
b='        align_metrics = {}\n        if self.config.align_params != {} and getattr(self.config, "compute_auxiliary_losses", True):\n'
assert s.count(a)==1
p.write_text(s.replace(a,b))
