"""Prepare clean-only smoke configuration and validate model input transforms on CPU."""
from pathlib import Path
from types import SimpleNamespace
import json
import os
import yaml
import torch
from lerobot.datasets.lerobot_dataset import LeRobotDataset
from lingbotvla.models import build_processor
from lingbotvla.models.vla.lingbot_vla.configuration_lingbot_vla import LingbotVLAV2Config
from lingbotvla.data.vla_data.utils import FeatureTransform

ROOT = Path('/competition')
REPO = ROOT / 'sources/lingbot-vla-v2'
cfg = yaml.safe_load((REPO/'configs/vla/robotwin/robotwin.yaml').read_text())
baseline = ROOT / 'outputs/pretrained_click_bell_smoke'
ckpt = baseline/'checkpoints/global_step_0/hf_ckpt'
ckpt.parent.mkdir(parents=True,exist_ok=True)
if not ckpt.exists():ckpt.symlink_to(os.path.relpath(ROOT/'models/lingbot-vla-v2-6b',ckpt.parent),target_is_directory=True)
cfg['model']['model_path'] = str(ckpt)
cfg['model']['tokenizer_path'] = str(ROOT/'models/Qwen3-VL-4B-Instruct')
cfg['data'].update(data_name='robotwin',train_path=str(ROOT/'data/lerobot/click_bell_clean_50'),
                   robot_config_root=str(ROOT/'configs/robot_configs'),
                   norm_stats_file=str(ROOT/'configs/click_bell_norm.json'),num_workers=2,use_future_image=False)
for key in ['joints','norm_type']:
    cfg['data'][key]=[str(x) if isinstance(x,dict) else x for x in cfg['data'][key]]
cfg['train'].update(output_dir=str(ROOT/'outputs/click_bell_training'),use_compile=False,
                    enable_gradient_checkpointing=True,micro_batch_size=1,global_batch_size=1,
                    use_wandb=False)
robot = yaml.safe_load((REPO/'configs/robot_configs/robotwin.yaml').read_text())
robot['norm_stats'] = str(ROOT/'configs/click_bell_norm.json')
robot_path=ROOT/'configs/robot_configs/robotwin.yaml'
robot_path.parent.mkdir(parents=True,exist_ok=True)
robot_path.write_text(yaml.safe_dump(robot,sort_keys=False))
(baseline/'lingbotvla_cli.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
(ROOT/'configs/click_bell_smoke.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
kwargs={**cfg['model'],**cfg['train']}
model_cfg=LingbotVLAV2Config(**kwargs)
processor=build_processor(cfg['model']['tokenizer_path'])
transform=FeatureTransform(str(robot_path),SimpleNamespace(**cfg['data']),model_cfg,processor,
                           norm_stats_path=cfg['data']['norm_stats_file'],chunk_size=50)
ds=LeRobotDataset('local/click_bell_clean_50',root=ROOT/'data/lerobot/click_bell_clean_50')
item=ds[0]
raw_action=torch.stack([ds[i]['action'] for i in range(50)])
item['action']=raw_action.clone()
item['action_is_pad']=torch.zeros(50,dtype=torch.bool)
result=transform.apply(item)
for key in ['state','actions','images']:
    assert torch.isfinite(result[key]).all(),key
assert result['state'].shape[-1]==55
assert result['actions'].shape==(50,55)
restored=transform.unapply({key:(value.clone() if isinstance(value,torch.Tensor) else value)
                           for key,value in result.items()})
assert restored['action'].shape==(50,14)
max_error=float((restored['action']-raw_action).abs().max())
assert max_error<1e-5,max_error
report={'status':'pass','dataset_episodes':ds.num_episodes,'dataset_frames':ds.num_frames,
        'state_shape':list(result['state'].shape),'action_shape':list(result['actions'].shape),
        'image_shape':list(result['images'].shape),'action_roundtrip_max_error':max_error,
        'weights':'specified general pretrained weights; no training performed',
        'normalization':'click_bell clean trajectories only; smoke configuration, not a 50-task submission'}
(ROOT/'reports/click-bell-preprocessing-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
