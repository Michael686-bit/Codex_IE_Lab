"""Prepare an explicitly labeled smoke client; preserve official task/success logic."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'sources/lingbot-vla-v2/experiment/robotwin/eval_policy_client_lingbotvla.py'
TARGET = ROOT/'sources/RoboTwin/script/eval_policy_client_lingbot_smoke.py'
text=SOURCE.read_text()
replacements={
    '    get_model = eval_function_decorator(policy_name, "get_model")':
    '    get_model = None  # The official client uses a remote WebSocket policy, not this unused local factory.',
    '    test_num = 100': '    test_num = int(usr_args.get("smoke_episodes", 100))',
    "    model = WebsocketClientPolicy(port=usr_args['port'])":
    "    model = WebsocketClientPolicy(host=usr_args.get('host', '0.0.0.0'), port=usr_args['port'])",
}
for before,after in replacements.items():
    assert text.count(before)==1,before
    text=text.replace(before,after)
TARGET.write_text(text)
deploy=ROOT/'sources/RoboTwin/script/deploy';deploy.mkdir(exist_ok=True)
for name in ['__init__.py','websocket_client_policy.py','msgpack_numpy.py']:
    shutil.copyfile(ROOT/'sources/lingbot-vla-v2/deploy'/name,deploy/name)
for setting in ['clean','randomized']:
    (ROOT/f'configs/click_bell_eval_{setting}.yaml').write_text(f'''task_name: click_bell
policy_name: lingbot_vla_v2
task_config: demo_{setting}
ckpt_setting: specified_pretrained_smoke
seed: 0
instruction_type: unseen
host: lingbo-policy-smoke
port: 9330
robo_name: robotwin
video_fps: 10
eval_video_log: true
smoke_episodes: 1
output_dir: /competition/outputs/evaluation/pretrained_smoke_{setting}
''')
(ROOT/'reports/eval-client-provenance.json').write_text(json.dumps({
    'official_source':str(SOURCE.relative_to(ROOT)),
    'official_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'smoke_client':str(TARGET.relative_to(ROOT)),
    'smoke_client_sha256':hashlib.sha256(TARGET.read_bytes()).hexdigest(),
    'changes':list(replacements.values()),
    'task_and_success_logic_changed':False,
    'submission_eligible':False,
    'purpose':'single-episode environment acceptance; not the official 100-episode benchmark'
},indent=2)+'\n')
print('Prepared smoke evaluation client and clean/randomized configurations.')
