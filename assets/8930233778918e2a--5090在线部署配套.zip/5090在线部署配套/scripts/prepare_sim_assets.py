"""Extract verified assets and one clean task; preserve archives and provenance."""
from pathlib import Path, PurePosixPath
import json
import os
import shutil
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'sources/RoboTwin'
jobs = [(ROOT / 'data/assets' / name, ROOT / 'data/assets') for name in
        ['embodiments.zip', 'objects.zip', 'background_texture.zip']]
jobs.append((ROOT / 'data/archives/dataset/click_bell/aloha-agilex_clean_50.zip',
             ROOT / 'data/raw/click_bell'))
status = {'status': 'extracting', 'archives': {}, 'started_at': time.time()}
report = ROOT / 'reports/assets-preparation.json'


def save():
    report.write_text(json.dumps(status, indent=2)+'\n')


def link(path, target):
    if path.is_symlink():
        if path.resolve() != target.resolve():
            raise RuntimeError(f'Existing symlink points elsewhere: {path}')
    elif path.exists():
        raise RuntimeError(f'Refusing to replace existing path: {path}')
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.symlink_to(os.path.relpath(target, path.parent), target_is_directory=True)


try:
    save()
    required = 0
    for archive, destination in jobs:
        with zipfile.ZipFile(archive) as z:
            required += sum(x.file_size for x in z.infolist())
    if shutil.disk_usage(ROOT).free < required + 80 * 1024**3:
        raise RuntimeError('Insufficient free space, including 80 GiB reserve')
    for archive, destination in jobs:
        destination.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive) as z:
            count = 0
            size = 0
            for member in z.infolist():
                name = PurePosixPath(member.filename)
                if name.is_absolute() or '..' in name.parts:
                    raise ValueError(f'Unsafe archive member: {name}')
                if '__MACOSX' in name.parts or name.name == '.DS_Store':
                    continue
                if (member.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError(f'Archive symlink not supported: {name}')
                z.extract(member, destination)
                if not member.is_dir():
                    count += 1
                    size += member.file_size
        status['archives'][str(archive.relative_to(ROOT))] = {'files': count, 'uncompressed_bytes': size}
        save()
        print('EXTRACTED', archive.name, count, size, flush=True)
    for name in ['objects', 'embodiments', 'background_texture']:
        link(REPO / 'assets' / name, ROOT / 'data/assets' / name)
    link(REPO / 'data/click_bell', ROOT / 'data/raw/click_bell')
    status['status'] = 'complete'
    status['finished_at'] = time.time()
    save()
except Exception as exc:
    status.update(status='failed', error=str(exc))
    save()
    raise
