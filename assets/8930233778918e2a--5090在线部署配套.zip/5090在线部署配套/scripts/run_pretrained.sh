#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
SETTING=clean
MODE=online_pretrained
COMMAND=(/competition/scripts/serve_pretrained.py)
docker image inspect lingbo-online-sim:cu128 >/dev/null
FREE=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -n 1 | tr -d ' ')
if (( FREE < 19000 )); then
  echo "GPU has ${FREE} MiB free; need at least 19000 MiB for model + simulator acceptance. Existing jobs were not changed." >&2
  exit 1
fi
python3 scripts/prepare_eval_client.py
NET=lingbo-online-internal
MODEL=lingbo-online-policy-closedloop
SIM=lingbo-online-sim-closedloop
STARTED_MODEL=false
STARTED_SIM=false
cleanup() {
  if [[ "$STARTED_SIM" == true ]]; then docker stop "$SIM" >/dev/null 2>&1 || true; fi
  if [[ "$STARTED_MODEL" == true ]]; then docker stop "$MODEL" >/dev/null 2>&1 || true; fi
}
trap cleanup EXIT
if ! docker network inspect "$NET" >/dev/null 2>&1; then docker network create --internal "$NET"; fi
for name in "$MODEL" "$SIM"; do
  if docker inspect "$name" >/dev/null 2>&1; then
    echo "Container $name already exists; inspect its logs before starting another run." >&2; exit 1
  fi
done
docker run -d --name "$MODEL" --init --gpus all --network "$NET" \
  --user "$(id -u):$(id -g)" --cap-drop ALL --security-opt no-new-privileges \
  -e HOME=/tmp -e HF_HUB_OFFLINE=1 -e HF_DATASETS_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 \
  -e HTTP_PROXY= -e HTTPS_PROXY= -e ALL_PROXY= -e http_proxy= -e https_proxy= -e all_proxy= -e NO_PROXY='*' -e no_proxy='*' \
  -e HF_HOME=/competition/cache/huggingface -e TRITON_CACHE_DIR=/competition/cache/triton \
  -e QWEN3VL_PATH=/competition/models/Qwen3-VL-4B-Instruct \
  -v "$PWD:/competition" -w /opt/lingbot-vla-v2 \
  --entrypoint python lingbo-online-model:cu128 "${COMMAND[@]}"
STARTED_MODEL=true
READY=false
for attempt in $(seq 1 120); do
  if [[ $(docker inspect "$MODEL" --format '{{.State.Running}}') != true ]]; then
    docker logs --tail 40 "$MODEL"; exit 1
  fi
  if docker exec "$MODEL" python -c 'import urllib.request; urllib.request.urlopen("http://127.0.0.1:9330/healthz",timeout=2).close()' >/dev/null 2>&1; then
    READY=true; break
  fi
  sleep 5
done
[[ "$READY" == true ]] || { echo 'Policy did not become ready; inspect model logs.' >&2; exit 1; }
STARTED_SIM=true
docker run --name "$SIM" --init --gpus all --network "$NET" \
  --user "$(id -u):$(id -g)" --cap-drop ALL --security-opt no-new-privileges \
  -e HOME=/tmp -e XDG_RUNTIME_DIR=/tmp -e NVIDIA_DRIVER_CAPABILITIES=compute,utility,graphics \
  -e HTTP_PROXY= -e HTTPS_PROXY= -e ALL_PROXY= -e http_proxy= -e https_proxy= -e all_proxy= -e NO_PROXY='*' -e no_proxy='*' \
  -e VK_ICD_FILENAMES=/etc/vulkan/icd.d/nvidia_icd.json \
  -e __EGL_VENDOR_LIBRARY_FILENAMES=/usr/share/glvnd/egl_vendor.d/10_nvidia.json \
  -e LINGBO_RAY_DENOISER=none -e TORCH_EXTENSIONS_DIR=/competition/cache/torch_extensions_5090 -e PYTHONUNBUFFERED=1 \
  -v /usr/share/vulkan/icd.d/nvidia_icd.json:/etc/vulkan/icd.d/nvidia_icd.json:ro \
  -v /usr/share/glvnd/egl_vendor.d/10_nvidia.json:/usr/share/glvnd/egl_vendor.d/10_nvidia.json:ro \
  -v "$PWD:/competition" -w /competition/sources/RoboTwin \
  --entrypoint python lingbo-online-sim:cu128 script/eval_policy_client_lingbot_smoke.py \
  --config "/competition/configs/click_bell_eval_${SETTING}.yaml" \
  --overrides --host "$MODEL" --ckpt_setting "${MODE}_smoke" \
  --output_dir /competition/outputs/evaluation/online_pretrained_smoke_clean
docker stop "$MODEL"
