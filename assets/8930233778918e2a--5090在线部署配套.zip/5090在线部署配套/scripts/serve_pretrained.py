"""Original published base weights only; no LoRA or prior training artifacts."""
import os,sys
sys.path.insert(0,'/opt/lingbot-vla-v2')
import torch,cv2,numpy as np
from lingbotvla.distributed.parallel_state import init_parallel_state
from deploy.lingbot_vla_v2_policy import LingbotVLAv2Server
from deploy.websocket_policy_server import WebsocketPolicyServer
import lingbotvla.models.vla.lingbot_vla.qwen2_action_expert as action_module
torch.distributed.init_process_group('gloo',init_method='file:///tmp/online-single-rank',rank=0,world_size=1)
init_parallel_state(dp_mode='ddp')
action_module.robby_moe_forward=None
torch.set_float32_matmul_precision('highest')
server=LingbotVLAv2Server(
    path_to_pi_model='/competition/outputs/pretrained_click_bell_smoke/checkpoints/global_step_0/hf_ckpt',
    robot_norm_path='/competition/configs/click_bell_norm.json',
    use_compile=False,use_bf16=True,use_fp32=False,use_length=50,chunk_ret=True)
original=server.infer
def infer(obs):
    for key,value in list(obs.items()):
        if key.startswith('observation.images.'):
            obs[key]=cv2.resize(value,(256,256),interpolation=cv2.INTER_AREA)
    reply=original(obs)
    if reply.get("action") is not None:
        action=np.asarray(reply["action"])
        assert action.shape == (50,14) and np.isfinite(action).all(), action.shape
    return reply
server.infer=infer
os.chdir('/opt/lingbot-vla-v2')
WebsocketPolicyServer(server,port=9330).serve_forever()
